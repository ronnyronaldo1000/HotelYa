//
//  BaseViewController.swift
//  HotelYa
//
//  Created by Ronaldo Rendon on 7/4/16.
//  Copyright © 2016 Ronny Rendon. All rights reserved.
//

import UIKit
import MapKit

class BaseViewController: UIViewController {

    let regionRadius: CLLocationDistance = 1000
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    /* alert user for errors */
    class func alertUser(fromViewController viewController: UIViewController, withTitle title: String, content: String, completionHandler:((UIAlertAction!)-> Void)) -> UIAlertController {
        
        let alertViewController = UIAlertController(title: title, message: content, preferredStyle: .Alert)
        
        //actions to the alert
        alertViewController.addAction(UIAlertAction(title: "Okay", style: .Default, handler: completionHandler))
        viewController.presentViewController(alertViewController, animated: true, completion: nil)
        
        return alertViewController
        
    }
    
    

}
