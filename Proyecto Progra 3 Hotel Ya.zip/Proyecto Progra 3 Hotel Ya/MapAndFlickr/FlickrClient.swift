//
//  FlickrClient.swift
//  HotelYa
//
//  Created by Ronaldo Rendon on 7/4/16.
//  Copyright © 2016 Ronny Rendon. All rights reserved.
//

import Foundation
import MapKit
import CoreData

class FlickrClient: NSObject {
    
    var photoCache = NSCache()
    lazy var isFetching = [String: NSURLSessionDataTask]()
    
    var session: NSURLSession
    
    override init() {
        session = NSURLSession(configuration: NSURLSessionConfiguration.defaultSessionConfiguration(), delegate: nil, delegateQueue: NSOperationQueue.mainQueue())
        // session = NSURLSession.sharedSession()
        
        super.init()
    }
    
    
    class func sharedInstance() -> FlickrClient {
        struct Singleton {
            static var sharedInstance = FlickrClient()
        }
        return Singleton.sharedInstance
    }
}
