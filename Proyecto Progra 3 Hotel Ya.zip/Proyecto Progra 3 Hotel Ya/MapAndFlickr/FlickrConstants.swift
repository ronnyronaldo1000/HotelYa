//
//  FlickrConstants.swift
//  HotelYa
//
//  Created by Ronaldo Rendon on 7/4/16.
//  Copyright © 2016 Ronny Rendon. All rights reserved.
//

import Foundation

extension FlickrClient {
    
    struct Methods {
        static let PhotoSearch = "flickr.photos.search"
    }
    
    struct Constants {
        static let BaseURL = "https://api.flickr.com/services/rest/"
        static let DataFormat = "json"
        static let NoJSONCallback = "1"
        static let BoundingBoxHalfWidth = 1.0
        static let BoundingBoxHalfHeight = 1.0
        static let APIKey = "39534582f9cbf02a42c334aba5821d8d"
        static let APISecret = ""
        static let Extras = "url_m"
    }
}