//
//  FlickrConvenience.swift
//  HotelYa
//
//  Created by Ronaldo Rendon on 7/4/16.
//  Copyright © 2016 Ronny Rendon. All rights reserved.
//

import Foundation
import MapKit

let MAX_PHOTOS = 100;

extension FlickrClient {    

    func searchPhotosByPin(pin: Pin, withRandomPage random: Bool, maxCount: Int, completion: (results: [(String, String)]?, error: String?)-> Void) -> NSURLSessionDataTask {
        
        var methodArgs = [
            "method": Methods.PhotoSearch,
            "api_key": Constants.APIKey,
            "bbox": boundingBoxStr(CLLocationCoordinate2D(latitude: pin.latitude.doubleValue, longitude: pin.longitude.doubleValue)),
            "extras": Constants.Extras,
            "per_page": min(maxCount, MAX_PHOTOS),
            "page": getRandomPage(pin, random: random),
            "format": Constants.DataFormat,
            "nojsoncallback": Constants.NoJSONCallback
        ]
        
        let urlString = Constants.BaseURL + FlickrClient.escapedParameters(methodArgs as! [String : AnyObject])
        let url = NSURL(string: urlString)!
        let request = NSURLRequest(URL: url)
        
        let task = FlickrClient.sharedInstance().session.dataTaskWithRequest(request) {data, response, error in
            if error != nil {
                print("download error from Flickr")
                completion(results: nil, error: "Download error from Flickr")
                return
            }
            
            
            let resultsDictionary = try! NSJSONSerialization.JSONObjectWithData(data!, options: .AllowFragments) as! NSDictionary
            switch(resultsDictionary["stat"] as! String) {
            case "ok":
                print("Results processed by Flickr!")
            case "fail":
                completion(results: nil, error: "Results failed to be processed by Flickr")
                return
            default:
                completion(results: nil, error: "Unknown API call at Flickr")
                return
            }
            
            let photos = resultsDictionary["photos"] as! NSDictionary
            let photoCount = min(Int((photos["total"] as! String))!, MAX_PHOTOS)
            let photosReturned = photos["photo"] as! [NSDictionary]
            
            var flickrPhotos = [(String, String)]()
            for desc in photosReturned {
                
                let photoId = (desc["id"] as? String) ?? ""
                let farmId = (desc["farm"] as? Int) ?? 0
                let server = (desc["server"] as? String) ?? ""
                let secret = (desc["secret"] as? String) ?? ""
                
                flickrPhotos.append((photoId, self.getURLToFlickrPhoto(photoId, farmId: farmId, server: server, secret: secret)))
            }
            completion(results: flickrPhotos, error: nil)
            
        }
        
        task.resume()
        return task
    }
    
    
    internal func getRandomPage(pin: Pin, random: Bool) -> Int {
        var pageNumber = 1
        
        if random == true {
            pageNumber = Int(arc4random_uniform(UInt32(10) + 1))
            // pageNumber = Int(arc4random_uniform(UInt32(((pin.numberOfPages != nil) ? (pin.numberOfPages!.intValue + 1) : 2 ))))
            
        }
        return pageNumber
    }

    
    internal func getURLToFlickrPhoto(photoId: String, farmId: Int, server: String, secret: String) -> String {
        return "https://farm\(farmId).staticflickr.com/\(server)/\(photoId)_\(secret)_b.jpg"
    }
    
    
    func boundingBoxStr(coordinate: CLLocationCoordinate2D) -> String {
        let lat = coordinate.latitude
        let lon = coordinate.longitude
        
        return "\(lon - Constants.BoundingBoxHalfWidth), \(lat - Constants.BoundingBoxHalfHeight), \(lon + Constants.BoundingBoxHalfWidth), \(lat + Constants.BoundingBoxHalfHeight)"
    }
    
    
    /*Borrowed code from TMDB project: - helper function:
    Given a dictionary of parameters, convert to a string for a url */
    class func escapedParameters(parameters: [String : AnyObject]) -> String {
        
        var urlVars = [String]()
        
        for (key, value) in parameters {
            
            /* Make sure that it is a string value */
            let stringValue = "\(value)"
            
            /* Escape it */
            let escapedValue = stringValue.stringByReplacingOccurrencesOfString(" ", withString: "+", options: NSStringCompareOptions.LiteralSearch, range: nil)
            
            /* Append it */
            urlVars += [key + "=" + "\(escapedValue)"]
            
        }
        
        return (!urlVars.isEmpty ? "?" : "") + urlVars.joinWithSeparator("&")
    }
}