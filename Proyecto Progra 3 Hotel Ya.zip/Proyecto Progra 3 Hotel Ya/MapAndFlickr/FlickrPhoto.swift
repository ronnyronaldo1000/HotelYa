//
//  FlickrPhoto.swift
//  HotelYa
//
//  Created by Ronaldo Rendon on 7/4/16.
//  Copyright © 2016 Ronny Rendon. All rights reserved.
//

import UIKit
import CoreData

@objc(FlickrPhoto)

class FlickrPhoto: NSManagedObject {
    struct Keys {
        static let Data = "data"
        static let Title = "title"
        static let ID = "id"
        static let Pin = "pin"
        static let URLString = "urlString"
    }
    
//    @NSManaged var data: NSData?
    @NSManaged var title: String
    @NSManaged var urlString: String
    @NSManaged var pin: Pin
    @NSManaged var id: String
    
    var isFetching: Bool = false
    
    
    override init(entity: NSEntityDescription, insertIntoManagedObjectContext context: NSManagedObjectContext?) {
        super.init(entity: entity, insertIntoManagedObjectContext: context)
    }
    
    init(dictionary: [String:AnyObject], context: NSManagedObjectContext) {
        
        let entity = NSEntityDescription.entityForName("FlickrPhoto", inManagedObjectContext: context)!
        super.init(entity: entity, insertIntoManagedObjectContext: context)
        
        self.urlString = dictionary[Keys.URLString] as! String
        self.pin = dictionary[Keys.Pin] as! Pin
        self.title = dictionary[Keys.Title] as! String
        self.id = dictionary[Keys.ID] as! String
        // data = nil
    }
    
    func setPhoto(dictionary: [String:AnyObject], context: NSManagedObjectContext) {
        urlString = dictionary[Keys.URLString] as! String
        pin = dictionary[Keys.Pin] as! Pin
        title = dictionary[Keys.Title] as! String
        id = dictionary[Keys.ID] as! String
        isFetching = false
        // data = nil
    }
    
}
