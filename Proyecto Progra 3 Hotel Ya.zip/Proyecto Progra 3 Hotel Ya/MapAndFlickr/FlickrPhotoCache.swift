//
//  FlickrPhotoCache.swift
//  HotelYa
//
//  Created by Ronaldo Rendon on 7/4/16.
//  Copyright © 2016 Ronny Rendon. All rights reserved.
//

import Foundation
import UIKit
import CoreLocation

extension FlickrClient {
    
    typealias DownloadCompletionHandler = (image:UIImage?,error: String?)->Void    
    
    func getImage(photo: FlickrPhoto, completion: DownloadCompletionHandler) -> UIImage? {
        if let image = photoCache.objectForKey(photo.id) as? UIImage {
            print("Found photo with id \(photo.id) in photos cache")
            return image
        } else if let imageData = NSData(contentsOfFile: photoPathInDocument(photo.id)) {
            print("retrieved photo from Document directory")
            return UIImage(data: imageData)
        } else {
            print("fetching photo \(photo.id) from Flickr")
    
            /*
            dispatch_async(dispatch_get_main_queue()) {
              //self.downloadImageFromFlickr(photo, completion: completion) //this caused context error
            }
            */
            downloadImageFromFlickr(photo, completion: completion)
            return nil
        }
    }
    
    
    
    public func purgeCache() {
        photoCache.removeAllObjects()
    }
    
    public func removePhotoCache(photo: FlickrPhoto) {
        photoCache.removeObjectForKey(photo.id)
        let photoFilePath = photoPathInDocument(photo.id)
        do {
            try NSFileManager.defaultManager().removeItemAtPath(photoFilePath)
            print("remove photo from directory with id: \(photo.id)")
        } catch {
            print("Silent error in deleting photos from directory: \(photo.id)")
        }
    }
    
    
    
    internal func photoPathInDocument(photoId: String)->String {
       // let documentsDirURL: NSURL = NSFileManager.defaultManager().URLForDirectory(.DocumentDirectory, inDomain: .UserDomainMask).first as! NSURL
        
        let documentsDirURL: NSURL = NSFileManager.defaultManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask).first!
        
        let docFullURL = documentsDirURL.URLByAppendingPathComponent(photoId)
        
        return docFullURL.path!
    }
    
    
    
    internal func downloadImageFromFlickr(photo: FlickrPhoto, completion: DownloadCompletionHandler) -> NSURLSessionDataTask {
        if let task = isFetching[photo.id] {
            return task
        }
        
        let task = taskForPhoto(photo, completion: {
            image, error in
            if let curImage = image {
                let filePath = self.photoPathInDocument(photo.id)
                let data = UIImagePNGRepresentation(curImage)
                data?.writeToFile(filePath, atomically: true) //save the image as data in document directory
            }
            completion(image: image, error: error)
        })
        
        task.resume()
        return task
    }
    
    //download photo from flickr if not in cache
    internal func taskForPhoto(photo: FlickrPhoto, completion: DownloadCompletionHandler) -> NSURLSessionDataTask {
        // let photoUrlString: String = photo.urlString.stringByReplacingOccurrencesOfString("http", withString: "https")
        
        let photoURL = NSURL(string: photo.urlString)!
        let request = NSURLRequest(URL: photoURL)
        let task = FlickrClient.sharedInstance().session.dataTaskWithRequest(request) {data, response, error in
            
            self.isFetching[photo.id] = nil
            
            if error != nil {
                completion(image: nil, error: "photo download error")
                return
            }
            
            if data != nil {
                if let fetchedImage = UIImage(data: data!) {
                    self.photoCache.setObject(fetchedImage, forKey: photo.id) //save the photo UIImage to cache
                    completion(image: fetchedImage, error: nil)
                    
                } else {
                    completion(image: nil, error: "Failed to load image data")
                }
                
            } else {
                completion(image: nil, error: "Failed to load image data")
            }
        }
        isFetching[photo.id] = task
        return task
    }
    
    
    
}
