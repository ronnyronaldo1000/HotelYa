//
//  HotelYa.swift
//  HotelYa
//
//  Created by Ronaldo Rendon on 7/4/16.
//  Copyright © 2016 Ronny Rendon. All rights reserved.
//

import Foundation
import MapKit

class HotelYa {

    let nombre: String?
    let localizacion: CLLocation
    let mapItem: MKMapItem
    let numeroCalle: String?
    let nombreCalle: String?
    let latitud: Double
    let longitud: Double

    init(mapItem: MKMapItem) {

        nombre = mapItem.name
        localizacion = mapItem.placemark.location!
        numeroCalle = mapItem.placemark.subThoroughfare
        nombreCalle = mapItem.placemark.thoroughfare
        latitud = (mapItem.placemark.location?.coordinate.latitude)!
        longitud = (mapItem.placemark.location?.coordinate.longitude)!
        self.mapItem = mapItem
    }

    func distanceFromLocation(location: CLLocation) -> Double {

        return location.distanceFromLocation(self.localizacion)
    }
}


