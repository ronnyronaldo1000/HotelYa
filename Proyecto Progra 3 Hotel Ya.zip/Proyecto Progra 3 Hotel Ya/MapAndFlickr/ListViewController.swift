//
//  ListViewController.swift
//  HotelYa
//
//  Created by Ronaldo Rendon on 7/4/16.
//  Copyright © 2016 Ronny Rendon. All rights reserved.
//

import UIKit
import MapKit

class ListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet var coffeeTableView: UITableView!
    @IBOutlet var mapView1: MKMapView!

    var vectorHotel = [HotelYa]()
    let locationManager = CLLocationManager()
    var currentLocation = CLLocation()

    var nombreHotel = ""
    var numCalle = ""
    var nomCalle = ""
    var nomCompleto = ""
    var hotelLatitud = ""
    var hotelLongitud = ""
    var mapItems = [MKMapItem]()

    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.Plain, target:nil, action:nil)

        mapView1.showsUserLocation = true
        mapView1.delegate = self

        self.title = "Hotel Ya"
        self.automaticallyAdjustsScrollViewInsets = false

        locationManager.startUpdatingLocation()
        locationManager.delegate = self
    }

    override func viewDidAppear(animated: Bool) {

        locationAuthStatus()
    }


    func agregarHotelesAlMapa() {

        for lugarHotel in self.vectorHotel {

            let annotation = MKPointAnnotation()
            annotation.coordinate = lugarHotel.localizacion.coordinate
            self.mapView1.addAnnotation(annotation)
        }
    }

    func mapView(mapView: MKMapView, didUpdateUserLocation userLocation: MKUserLocation) {

        if let loc = userLocation.location {
            buscarHoteles(loc)
        }
    }

    func locationAuthStatus() {

        if CLLocationManager.authorizationStatus() == .AuthorizedWhenInUse {
            mapView1.showsUserLocation = true
        } else {

            locationManager.requestWhenInUseAuthorization()
        }
    }

    func buscarHoteles(location: CLLocation) {

        let request = MKLocalSearchRequest()
        request.naturalLanguageQuery = "Hotel"
        request.region = MKCoordinateRegionMakeWithDistance(location.coordinate, 3000, 3000)
        mapView1.setRegion(request.region, animated: true)
        let search = MKLocalSearch(request: request)
        search.startWithCompletionHandler { (response: MKLocalSearchResponse?, error: NSError?) -> Void in

            if let hotelMapaItems = response?.mapItems {

                self.mapItems = hotelMapaItems
            }
            //Ordenar hoteles de menor a mayor distancia
            self.vectorHotel = (self.mapItems.map({ HotelYa(mapItem: $0) }))
            self.vectorHotel.sortInPlace({ (coffee1, coffee2) -> Bool in
                coffee1.distanceFromLocation(self.currentLocation) < coffee2.distanceFromLocation(self.currentLocation)
            })
            self.coffeeTableView.reloadData()
            self.agregarHotelesAlMapa()
        }
    }

    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {

        if let location = locations.first {

            currentLocation = location
        }

        if currentLocation.verticalAccuracy < 1000 && currentLocation.horizontalAccuracy < 1000 {

            locationManager.stopUpdatingLocation()
            print("Current location is: \(currentLocation)")
            buscarHoteles(currentLocation)
        }
    }

    func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
        print("Location Manager Error: \(error)")
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        if self.vectorHotel.count < 21 {

            return self.vectorHotel.count
        } else {

            return 20
        }
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCellWithIdentifier("Cell") as! TableViewCell
        let lugarHotel = self.vectorHotel[indexPath.row]
        if let lugarHotelNombre = lugarHotel.nombre
        {
            nombreHotel = lugarHotelNombre
        }
        cell.titleLabel.text = nombreHotel
        if let numCalleHotel = lugarHotel.numeroCalle {

            numCalle = numCalleHotel
        }
        if let nomCalleHotel = lugarHotel.nombreCalle {

            nomCalle = nomCalleHotel
        }
        nomCompleto = numCalle + " " + nomCalle
        cell.subtitleLabel.text = nomCompleto

        let millas = (lugarHotel.distanceFromLocation(self.currentLocation) * 0.000621371)
        let millasHotel  = Double(round(10 * millas)/10)

        cell.milesLabel.text = "\(millasHotel) mi"

        return cell
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {

        let dvc = segue.destinationViewController as! MapViewController

        let mapHotelVector = self.vectorHotel
        dvc.mapHotelVector = mapHotelVector

        let locActual = self.currentLocation
        dvc.locActual = locActual
    }

   /* func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        //let coffeePlace = self.vectorHotel[indexPath.row]
        hotelLatitud = String(lugarHotel.latitude)
        hotelLongitud = String(coffeePlace.longitude)
        UIApplication.sharedApplication().openURL(NSURL(string: "http://maps.apple.com/maps?daddr=\(coffeeShopLat),\(coffeeShopLong)")!)

        coffeeTableView.deselectRowAtIndexPath(indexPath, animated: true)
    }*/
}

