//
//  MapViewController.swift
//  HotelYa
//
//  Created by Ronaldo Rendon on 7/4/16.
//  Copyright © 2016 Ronny Rendon. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    var mapHotelVector = [HotelYa]()
    
    @IBOutlet var mapView2: MKMapView!

    var locActual = CLLocation()
    var nomCalle = ""
    var numCalle = ""
    var nomCompleto = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "HotelYa"

        mapView2.showsUserLocation = true

        agregarHotelesAlMapa()
        centroMapa(locActual)
    }

    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {

        if annotation.isEqual(mapView.userLocation) {
            return nil
        }

        let reuseIdentifier = "pin"

        var pin = mapView.dequeueReusableAnnotationViewWithIdentifier(reuseIdentifier) as? MKPinAnnotationView

        if pin == nil {

            pin = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseIdentifier)
            pin!.canShowCallout = true
            pin!.rightCalloutAccessoryView = UIButton(type: .DetailDisclosure)

        } else {

            pin!.annotation = annotation
        }

        return pin
    }

    func mapView(mapView: MKMapView, annotationView view: MKAnnotationView,
        calloutAccessoryControlTapped control: UIControl) {

            let selectedLoc = view.annotation
            let currentLocMapItem = MKMapItem.mapItemForCurrentLocation()
            let selectedPlacemark = MKPlacemark(coordinate: selectedLoc!.coordinate, addressDictionary: nil)
            let selectedMapItem = MKMapItem(placemark: selectedPlacemark)
            let mapItems = [selectedMapItem, currentLocMapItem]
            let launchOptions = [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]
            
            MKMapItem.openMapsWithItems(mapItems, launchOptions:launchOptions)
    }

    func agregarHotelesAlMapa() {

        for lugarHotel in self.mapHotelVector {

            let anotacion = MKPointAnnotation()
            anotacion.coordinate = lugarHotel.localizacion.coordinate
            if let coffeePlaceName = lugarHotel.nombre {

                anotacion.title = coffeePlaceName
            }
            if let stNumber = lugarHotel.numeroCalle {

                numCalle = stNumber
            }
            if let stName = lugarHotel.nombreCalle {

                nomCalle = stName
            }
            anotacion.subtitle = numCalle + " " + nomCalle
            self.mapView2.addAnnotation(anotacion)
        }
    }

    func centroMapa(location: CLLocation) {

        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, 2800, 2800)
        mapView2.setRegion(coordinateRegion, animated: true)
    }
}


