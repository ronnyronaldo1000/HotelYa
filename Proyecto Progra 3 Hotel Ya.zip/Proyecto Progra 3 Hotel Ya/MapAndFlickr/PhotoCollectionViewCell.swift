//
//  PhotoCollectionViewCell.swift
//  HotelYa
//
//  Created by Ronaldo Rendon on 7/4/16.
//  Copyright © 2016 Ronny Rendon. All rights reserved.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    

    
    @IBOutlet weak var loadingIndicator: UIActivityIndicatorView!
    @IBOutlet weak var photoView: UIImageView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        photoView = UIImageView(frame: contentView.bounds) //image placeholder
        photoView.contentMode = .ScaleAspectFit
        contentView.addSubview(photoView)
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    
    
    /*
    var flickrPhoto: UIImage {
        set {
            self.photoView.image = newValue
        }
        
        get {
            return self.photoView.image ?? UIImage(named: "loading")!
        }
    }
    */
}
