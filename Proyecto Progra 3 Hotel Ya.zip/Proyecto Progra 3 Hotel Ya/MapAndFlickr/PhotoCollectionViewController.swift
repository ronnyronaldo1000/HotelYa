//
//  PhotoCollectionViewController.swift
//  HotelYa
//
//  Created by Ronaldo Rendon on 7/4/16.
//  Copyright © 2016 Ronny Rendon. All rights reserved.
//

import UIKit
import MapKit
import CoreData

class PhotoCollectionViewController: BaseViewController {
    
    var selectedPin: Pin!
    var photos: [FlickrPhoto]!
    var alertViewController: UIAlertController?
    
    
    var selectedIndexes = [NSIndexPath]()
    var insertedIndexPaths: [NSIndexPath]!
    var deletedIndexPaths: [NSIndexPath]!
    var updatedIndexPaths: [NSIndexPath]!
    
    @IBOutlet weak var cancelButton: UIBarButtonItem!
    @IBOutlet weak var mapScreenshot: MKMapView!
    @IBOutlet weak var photoCollectionView: UICollectionView!
    @IBOutlet weak var newCollectionButton: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        photoCollectionView.delegate = self
        photoCollectionView.dataSource = self
        
        newCollectionButton.enabled = true
        let selectedLocationAnnot = TouringLocationAnnotation(tourLocationPin: selectedPin)
        mapScreenshot.addAnnotation(selectedLocationAnnot) //annotation on the map
        
        
        if selectedPin.photos.count == 0 {
            newCollectionButton.enabled = false
            newButtonClicked(self)
        }
        
        let selectedLocation = CLLocation(latitude: selectedPin.latitude.doubleValue, longitude: selectedPin.longitude.doubleValue)
        centerMapOnLocation(selectedLocation) //show the selected pin on map
        
        do {
            try self.fetchedResultsController.performFetch()
        } catch let error as NSError {
            //alert user for errors
            self.alertUserForError("Errors in fetching photos")
        }
    }
    
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        let layout : UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: -65, left: 0, bottom: 0, right: 0)
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        
        let width = floor(self.photoCollectionView.frame.size.width/3)
        layout.itemSize = CGSize(width: width, height: width)
        photoCollectionView.collectionViewLayout = layout
    }
    
    
    
    //dismiss the current view
    @IBAction func cancel(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius * 2.0, regionRadius * 2.0)
        mapScreenshot.setRegion(coordinateRegion, animated: true)
    }
    
    func configureCell(cell: PhotoCollectionViewCell, atIndexPath indexPath: NSIndexPath) {
        print("configure cell!!")
        if let photo = self.fetchedResultsController.objectAtIndexPath(indexPath) as? FlickrPhoto {
        
            let image = FlickrClient.sharedInstance().getImage(photo, completion: {image, error in
                if error != nil {
                    self.alertUserForError("Error in getting photos from Flickr") //alert user
                } else {
                    dispatch_async(dispatch_get_main_queue(), {
                        // cell.photoView.image = image
                        self.photoCollectionView.reloadItemsAtIndexPaths([indexPath])
                    })
                }
            })
            
            if image != nil {
                cell.photoView.image = image
                cell.photoView.hidden = false
                cell.loadingIndicator.hidden = true
                cell.loadingIndicator.stopAnimating()
            } else {
                cell.photoView.hidden = true
                cell.loadingIndicator.hidden = false
                cell.loadingIndicator.startAnimating()
            }
            
            //gray out the selected photo
            if let _ = selectedIndexes.indexOf(indexPath) {
                cell.photoView.alpha = 0.25 // gray out
            } else {
                cell.photoView.alpha = 1.0
            }
        }
        
    }
    
    
    func updateBottomBarButton() {
        if selectedIndexes.count > 0 {
            newCollectionButton.title = "Quitar fotos seleccionadas"
        } else {
            newCollectionButton.title = "Nuevas Fotos"
        }
    }
    
    
    @IBAction func newButtonClicked(sender: AnyObject) {
        
        print("fetching new photos now...")
        if selectedIndexes.count > 0 {
            deleteSelectedPhoto()
        } else {
            newCollectionButton.enabled = false
            deleteAllPhotos() //delete all current photos from coredata
            
            FlickrClient.sharedInstance().searchPhotosByPin(selectedPin, withRandomPage: true, maxCount: 15, completion: { (results, error) -> Void in
                if error != nil {
                    self.alertUserForError(error!)
                } else if let data = results {
                    
                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                        for (photoId, photoUrl) in data {
                            let dict: [String: AnyObject] = [
                                FlickrPhoto.Keys.ID: photoId,
                                FlickrPhoto.Keys.Pin: self.selectedPin,
                                FlickrPhoto.Keys.URLString: photoUrl,
                                FlickrPhoto.Keys.Title: photoId
                            ]
                            let curPhoto = FlickrPhoto(dictionary: dict, context: self.sharedContext)
                            print("photo url: \(photoUrl), photoId: \(photoId)")
                        }
                        self.newCollectionButton.enabled = true
                    }) //dispatch_async
                }
           })
        }
    }

    
    var sharedContext: NSManagedObjectContext {
        // print("returning shared context")
        return CoreDataStackManager.sharedInstance().managedObjectContext!
    }
    
    
    lazy var fetchedResultsController: NSFetchedResultsController = {
        
        let fetchRequest = NSFetchRequest(entityName: "FlickrPhoto")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "id", ascending: true)]
        fetchRequest.predicate = NSPredicate(format: "pin == %@", self.selectedPin)
        
        let fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: self.sharedContext, sectionNameKeyPath: nil, cacheName: nil)
        fetchedResultsController.delegate = self
        //print("finished fetchresults controller")
        
        return fetchedResultsController
        
    }()
    
    
    func deleteSelectedPhoto() {
        
        defer {

            selectedIndexes = [NSIndexPath]()
            updateBottomBarButton() //update the button title
        }
        
        var photosToDelete = [FlickrPhoto]()
        for indexPath in selectedIndexes {
            photosToDelete.append(fetchedResultsController.objectAtIndexPath(indexPath) as! FlickrPhoto)
        }
        
        if photosToDelete.count > 0 {
            for photo in photosToDelete {
                FlickrClient.sharedInstance().removePhotoCache(photo)
                sharedContext.deleteObject(photo)
                
            }
        }
    } //deleteSelectedPhoto
    
    
    
    func deleteAllPhotos() {
        
        if let allPhotos = fetchedResultsController.fetchedObjects as? [FlickrPhoto] {
            for photo in allPhotos {
                sharedContext.deleteObject(photo)
                FlickrClient.sharedInstance().removePhotoCache(photo)
            }
            selectedIndexes = [NSIndexPath]()
            updateBottomBarButton() //update the button title
        }
    } //deleteAllPhotos

    
    internal func alertUserForError(error: String) -> Void {
        //warning users on error
        dispatch_async(dispatch_get_main_queue()) {
            self.alertViewController = BaseViewController.alertUser(fromViewController: self, withTitle: "Error in fetching photos", content: error, completionHandler: { (alertAction) -> Void in
            self.alertViewController!.dismissViewControllerAnimated(true, completion: nil)
            })
        }
    }
    
    
    
}

extension PhotoCollectionViewController: NSFetchedResultsControllerDelegate {
    
    
    
    // MARK: - Fetched Results Controller Delegate
    
    // Whenever changes are made to Core Data the following three methods are invoked. This first method is used to create
    // three fresh arrays to record the index paths that will be changed.
    func controllerWillChangeContent(controller: NSFetchedResultsController) {
        // We are about to handle some new changes. Start out with empty arrays for each change type
        insertedIndexPaths = [NSIndexPath]()
        deletedIndexPaths = [NSIndexPath]()
        updatedIndexPaths = [NSIndexPath]()
        
        print("in controllerWillChangeContent")
    }
    
    // The second method may be called multiple times, once for each FlickrPhoto object that is added, deleted, or changed.
    // We store the incex paths into the three arrays.
    func controller(controller: NSFetchedResultsController, didChangeObject anObject: AnyObject, atIndexPath indexPath: NSIndexPath?, forChangeType type: NSFetchedResultsChangeType, newIndexPath: NSIndexPath?) {
        
        switch type{
            
        case .Insert:
            print("Insert an item")
            // Here we are noting that a new FlickrPhoto instance has been added to Core Data. We remember its index path
            // so that we can add a cell in "controllerDidChangeContent". Note that the "newIndexPath" parameter has
            // the index path that we want in this case
            insertedIndexPaths.append(newIndexPath!)
            break
        case .Delete:
            print("Delete an item")
            // Here we are noting that a FlickrPhoto instance has been deleted from Core Data. We keep remember its index path
            // so that we can remove the corresponding cell in "controllerDidChangeContent". The "indexPath" parameter has
            // value that we want in this case.
            deletedIndexPaths.append(indexPath!)
            break
        case .Update:
            print("Update an item.")
            // We don't expect FlickrPhoto instances to change after they are created. But Core Data would
            // notify us of changes if any occured. This can be useful if you want to respond to changes
            // that come about after data is downloaded. For example, when an images is downloaded from
            // Flickr in the Virtual Tourist app
            updatedIndexPaths.append(indexPath!)
            break
        case .Move:
            print("Move an item. We don't expect to see this in this app.")
            break
        default:
            print("in second controller after cases!!")
            break
        }
    }
    
    // This method is invoked after all of the changed in the current batch have been collected
    // into the three index path arrays (insert, delete, and upate). We now need to loop through the
    // arrays and perform the changes.
    //
    // The most interesting thing about the method is the collection view's "performBatchUpdates" method.
    // Notice that all of the changes are performed inside a closure that is handed to the collection view.
    func controllerDidChangeContent(controller: NSFetchedResultsController) {
        
        //print("in controllerDidChangeContent, batch operations. changes.count: \(insertedIndexPaths.count + deletedIndexPaths.count)")
        
        photoCollectionView.performBatchUpdates({() -> Void in
            
            for indexPath in self.insertedIndexPaths {
                self.photoCollectionView.insertItemsAtIndexPaths([indexPath])
            }
            
            for indexPath in self.deletedIndexPaths {
                self.photoCollectionView.deleteItemsAtIndexPaths([indexPath])
            }
            
            for indexPath in self.updatedIndexPaths {
                self.photoCollectionView.reloadItemsAtIndexPaths([indexPath])
            }
            
            }, completion: {done in
                self.newCollectionButton.enabled = true //re-enable
            })
    }

    
}


extension PhotoCollectionViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return self.fetchedResultsController.sections?.count ?? 0
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let sectionInfo = self.fetchedResultsController.sections![section]
        
        print("number Of Cells: \(sectionInfo.numberOfObjects)")
        return sectionInfo.numberOfObjects
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        let cell = photoCollectionView.dequeueReusableCellWithReuseIdentifier("photoViewCell", forIndexPath: indexPath) as! PhotoCollectionViewCell
        configureCell(cell, atIndexPath: indexPath)
        
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        let cell = photoCollectionView.cellForItemAtIndexPath(indexPath) as! PhotoCollectionViewCell
        
        //when a cell is tapped, toggle its presence for highlight
        if let index = selectedIndexes.indexOf(indexPath) {
            selectedIndexes.removeAtIndex(index)
        } else {
            selectedIndexes.append(indexPath)
        }
        
        //reconfigure the cell
        configureCell(cell, atIndexPath: indexPath)
        
        updateBottomBarButton()
    }
    
}