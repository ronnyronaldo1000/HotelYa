//
//  Pin.swift
//  HotelYa
//
//  Created by Ronaldo Rendon on 7/4/16.
//  Copyright © 2016 Ronny Rendon. All rights reserved.
//

import UIKit
import MapKit
import CoreData

@objc(Pin)

class Pin: NSManagedObject {
    
    var isFetchingPhotos = false
    
    struct Keys {
        static let Latitude = "latitude"
        static let Longitude = "longitude"
        static let Name = "name"
        static let NumberOfPhotos = "numberOfPhotos"
        static let NumberOfPages = "numberOfPages"
        
        static let Photos = "photos"
    }
    
    @NSManaged var latitude: NSNumber!
    @NSManaged var longitude: NSNumber!
    @NSManaged var name: String?
   // @NSManaged var numberOfPhotos: NSNumber?
   // @NSManaged var numberOfPages: NSNumber?
    @NSManaged var photos: NSSet
    
    
    override init(entity: NSEntityDescription, insertIntoManagedObjectContext context: NSManagedObjectContext?) {
        super.init(entity: entity, insertIntoManagedObjectContext: context)
    }
    
    init(dictionary: [String:AnyObject], context: NSManagedObjectContext) {
        let entity = NSEntityDescription.entityForName("Pin", inManagedObjectContext: context)!
        super.init(entity: entity, insertIntoManagedObjectContext: context)
        
        self.longitude = NSNumber(double: dictionary[Pin.Keys.Longitude] as! CLLocationDegrees) //21.293512791522
        self.latitude = NSNumber(double: dictionary[Pin.Keys.Latitude] as! CLLocationDegrees) //.doubleValue  //-157.8288382014 //
        print(dictionary[Pin.Keys.Latitude] as! NSNumber)
        name = dictionary[Pin.Keys.Name] as! String //use coordinate as name
        
        // getGeocodeName() //not working
    }
    
    
    func fetchPhotosFromFlickr(completion: (success: Bool, error: String?) -> Void) {
        //fetch photos from flickr
        //TODO: handle the in-progress request while another request is made
        if isFetchingPhotos == true {
            completion(success: false, error: "Another fetch request is in progress")
            return
        }
    }
    
    
    
    func isValid() -> Bool {
        guard let _ = self.latitude, let _ = self.longitude else {
            return false
        }
        return true
    }
    
    
    func getGeocodeName() {
        //reverse geocode location
        CLGeocoder().reverseGeocodeLocation(CLLocation(latitude: latitude.doubleValue, longitude: longitude.doubleValue), completionHandler: {(placemarks, error) -> Void in
            
            if error != nil {
                print("reverse geocoding failed with error: \(error)")
                return
            }
            
            if placemarks!.count > 0 {
                let firstPlaceMark = placemarks![0]
                
                if let placeName = firstPlaceMark.subLocality {
                    self.name = placeName
                } else {
                    self.name = firstPlaceMark.country
                }
                print("success getting geocode name for the coordinate!")
            }
        })
    }
    
}
