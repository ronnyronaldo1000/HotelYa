//
//  TouringLocation.swift
//  HotelYa
//
//  Created by Ronaldo Rendon on 7/4/16.
//  Copyright © 2016 Ronny Rendon. All rights reserved.
//

import Foundation
import MapKit

class TouringLocationAnnotation: NSObject, MKAnnotation {
    
    var tourLocationPin: Pin
    var title: String? {
        return tourLocationPin.name
    }
    
    var coordinate: CLLocationCoordinate2D {
        return CLLocationCoordinate2DMake(tourLocationPin.latitude.doubleValue, tourLocationPin.longitude.doubleValue)
    }
    
    init(tourLocationPin: Pin) {
        self.tourLocationPin = tourLocationPin
        super.init()
    }
    
    /*
    var subtitle: String? {
        var subtitle: String? = nil
        
        if let annoTitle = title {
            subtitle = annoTitle
        }
        
        return subtitle
    }
    */
}
