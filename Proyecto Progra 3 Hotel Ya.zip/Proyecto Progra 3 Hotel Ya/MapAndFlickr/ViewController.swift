//
//  ViewController.swift
//  HotelYa
//
//  Created by Ronaldo Rendon on 7/4/16.
//  Copyright © 2016 Ronny Rendon. All rights reserved.
//

import UIKit
import MapKit
import CoreData
import CoreLocation

class ViewController: BaseViewController {


    @IBOutlet weak var mapView: MKMapView!
    //@IBOutlet weak var mapView: MKMapView!
    
 
    
    var myPin: MKPinAnnotationView?
    var editModeOn = false
    var alertViewController: UIAlertController?
    let longPressRecognizer = UILongPressGestureRecognizer()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        longPressRecognizer.addTarget(self, action: "addMapAnnotation:")
        mapView.delegate = self
        self.navigationItem.rightBarButtonItem = self.editButtonItem() //toggle edit and Done
        self.navigationItem.title = "HotelYa"
        self.navigationItem.leftBarButtonItem?.title = "atras"
        fetchedResultsController.delegate = self
        loadLastShownRegion()
        
        
        do {
            try self.fetchedResultsController.performFetch()
            
            if let savedPins = self.fetchedResultsController.fetchedObjects {
                for pin in savedPins {
                    showPinOnMap(pin as! Pin)                    
                }
            }

        } catch let error as NSError {
            self.alertUserForError("Error in retrieving pins from database")
        }
        
        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        mapView.addGestureRecognizer(longPressRecognizer)
    }
    
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        mapView.removeGestureRecognizer(longPressRecognizer)
    }
    
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        //checkLocationAuthorizationStatus()
    }
    
    
    //mostrar un pin como una anotacion en el mapa
    func showPinOnMap(pin: Pin) {
        
        if pin.isValid() { //check if the pin has coordinate set up
            let locationAnnot = TouringLocationAnnotation(tourLocationPin: pin)
            dispatch_async(dispatch_get_main_queue()) {
                self.mapView.addAnnotation(locationAnnot)
            }
        } else {
            //print("pin is invalid")
            self.alertUserForError("The pin is invalid")
        }
        
    }
    
    //Funcion para poder mover el mapa
    private func configurarCamara(){
        mapView.camera.altitude = 1400
        mapView.camera.pitch = 50
        mapView.camera.heading = 180
        
    }

    
    
    /* method for callout pin view */
    func showPhotosForPin(sender: UIButton) {
        print("showing photos for pin now!")
    }
    
    
    func addMapAnnotation(gestureRecognizer: UIGestureRecognizer) {
        if gestureRecognizer.state == UIGestureRecognizerState.Began {
            let touchPoint = gestureRecognizer.locationInView(mapView)
            let newCoordinate = mapView.convertPoint(touchPoint, toCoordinateFromView: mapView)
            
            let locationDictionary: [String:AnyObject] = [
                Pin.Keys.Name: "\(newCoordinate.latitude, newCoordinate.longitude)",
                Pin.Keys.Latitude: newCoordinate.latitude,
                Pin.Keys.Longitude: newCoordinate.longitude
            ]
            
            //use the location name as title
            CLGeocoder().reverseGeocodeLocation(CLLocation(latitude: newCoordinate.latitude, longitude: newCoordinate.longitude), completionHandler: {(placemarks, error) -> Void in
                var locationNameStr = ""
                
                if error != nil {
                    print("reverse geocoding failed with error: \(error)")
                    //return
                } else if placemarks!.count > 0 {
                    let firstPlace = placemarks![0] as CLPlacemark
                    
                    if firstPlace.locality != nil {
                        locationNameStr = "Un lugar en \(firstPlace.locality!)"
                    }
                    else if firstPlace.country != nil {
                        locationNameStr = "A lugar en \(firstPlace.country!)"
                    }
                }

                //create a new pin
                let newPin = Pin(dictionary: locationDictionary, context: self.sharedContext)
                newPin.name = locationNameStr
                
                do {
                    try self.sharedContext.save()
                    dispatch_async(dispatch_get_main_queue()) {
                        self.showPinOnMap(newPin)
                    }
                } catch {
                    self.alertUserForError("Error in saving the new pin, please try later")
                }
                
            })
        
        }
    }
    
    
    lazy var fetchedResultsController: NSFetchedResultsController = {
        
        let fetchRequest = NSFetchRequest(entityName: "Pin")
        
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        
        let fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest,
            managedObjectContext: self.sharedContext,
            sectionNameKeyPath: nil,
            cacheName: nil)
        
        return fetchedResultsController
        
        }()
    
    
    override func setEditing(editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)
        
        if editing {
            
            let titleDict: NSDictionary = [NSForegroundColorAttributeName: UIColor.redColor()
            ]
            navigationController?.navigationBar.titleTextAttributes = titleDict as! [String : AnyObject]
            
            self.navigationItem.title = "Seleccione para quitar"
            editModeOn = true
        } else {
            print("done with editing the pins")
            let titleDict: NSDictionary = [NSForegroundColorAttributeName: UIColor.blackColor()
            ]
            navigationController?.navigationBar.titleTextAttributes = titleDict as! [String : AnyObject]
            self.navigationItem.title = "HotelYa"
            self.navigationItem.leftBarButtonItem?.title = "atras"
            editModeOn = false
        }
    }
    
    internal func alertUserForError(error: String) -> Void {
        //warning users on error
        dispatch_async(dispatch_get_main_queue()) {
            self.alertViewController = BaseViewController.alertUser(fromViewController: self, withTitle: "Error in fetching photos", content: error, completionHandler: { (alertAction) -> Void in
                self.alertViewController!.dismissViewControllerAnimated(true, completion: nil)
            })
        }
    }
    
    
    internal func loadLastShownRegion() {
        //load last shown region from UserDefaults
        guard NSUserDefaults.standardUserDefaults().doubleForKey(TouristMapKeys.Latitude) == 0 else {
            
            let initLat = NSUserDefaults.standardUserDefaults().doubleForKey(TouristMapKeys.Latitude)
            let initLon = NSUserDefaults.standardUserDefaults().doubleForKey(TouristMapKeys.Longitude)
            let initLatDelta = NSUserDefaults.standardUserDefaults().doubleForKey(TouristMapKeys.LatDelta)
            let initLonDelta = NSUserDefaults.standardUserDefaults().doubleForKey(TouristMapKeys.LonDelta)
            let initRegion = MKCoordinateRegionMake(CLLocationCoordinate2DMake(initLat, initLon), MKCoordinateSpanMake(initLatDelta, initLonDelta))
            mapView.setRegion(initRegion, animated: true)
            
            return
        }
    }
    
    
    struct TouristMapKeys {
        static let Latitude = "LATITUDE"
        static let Longitude = "LONGITUDE"
        static let LatDelta = "LAT_DELTA"
        static let LonDelta = "LON_DELTA"
    }
}


extension ViewController: NSFetchedResultsControllerDelegate {
    
    
    
    func controller(controller: NSFetchedResultsController, didChangeObject anObject: AnyObject, atIndexPath indexPath: NSIndexPath?, forChangeType type: NSFetchedResultsChangeType, newIndexPath: NSIndexPath?) {
        let pin = anObject as! Pin
        switch type {
        case .Insert:
            print("Inserting a pin")
            // showPinOnMap(pin)
        case .Delete:
            print("Deleted a pin")
        default:
            //do nothing
            return
        }
    }
    
    
    var sharedContext: NSManagedObjectContext {
        return CoreDataStackManager.sharedInstance().managedObjectContext!
    }
}



extension ViewController: MKMapViewDelegate {
    
    
    //tipos de vista del mapa
    @available(iOS 9.0, *)
    @IBAction func tipoVista(sender: AnyObject) {
        switch sender.selectedSegmentIndex{
        case 1:
            mapView.mapType = MKMapType.SatelliteFlyover
            configurarCamara()
            
        case 2:
            mapView.mapType = MKMapType.HybridFlyover
            configurarCamara()
            
        default:
            mapView.mapType = MKMapType.Standard
            configurarCamara()
        }
    }
   
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        
        if let anno = annotation as? TouringLocationAnnotation {
            let reusedPinId = "pin"
            //print("calling the viewForAnnotation delegate")
            var pinView: MKPinAnnotationView!
            if let dequeuedView = mapView.dequeueReusableAnnotationViewWithIdentifier(reusedPinId)
                as? MKPinAnnotationView { // 2
                    dequeuedView.annotation = anno
                    pinView = dequeuedView
            } else {
                // 3
                pinView = MKPinAnnotationView(annotation: anno, reuseIdentifier: reusedPinId)
                
            }
            pinView.canShowCallout = true
            if #available(iOS 9.0, *) {
                pinView.pinTintColor = UIColor.purpleColor()
            } else {
                // Fallback on earlier versions
            }
            pinView.animatesDrop = true
            /*
            pinView.calloutOffset = CGPoint(x: -5, y: 5)
            let btn = UIButton(type: .DetailDisclosure)
            btn.addTarget(self, action: Selector("showPhotosForPin:"), forControlEvents: UIControlEvents.TouchUpInside)
            
            pinView.rightCalloutAccessoryView = btn //UIButton.buttonWithType(.DetailDisclosure) as! UIView
            */
            return pinView
        }
        return nil
    }
    
    /*
    //call out
    func mapView(mapView: MKMapView!, annotationView view: MKAnnotationView!, calloutAccessoryControlTapped control: UIControl!) {
        print("callout accessory control triggered!")
        /*
        if let annotation = view.annotation as? TouringLocationAnnotation {
            mapView.removeAnnotation(annotation)
        }
        */
        let annotation = view.annotation as! TouringLocationAnnotation
        if control == view.rightCalloutAccessoryView {
            print("right callout button is clicked")
        }
    }
    */
    
    /* cache the map view for app to use when the app is restarted */
    func mapView(mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
        //cache the last view region
        NSUserDefaults.standardUserDefaults().setDouble(mapView.centerCoordinate.latitude, forKey: TouristMapKeys.Latitude)
        NSUserDefaults.standardUserDefaults().setDouble(mapView.centerCoordinate.longitude, forKey: TouristMapKeys.Longitude)
        NSUserDefaults.standardUserDefaults().setDouble(mapView.region.span.latitudeDelta, forKey: TouristMapKeys.LatDelta)
        NSUserDefaults.standardUserDefaults().setDouble(mapView.region.span.longitudeDelta, forKey: TouristMapKeys.LonDelta)
        
    }
    
    
    func mapView(mapView: MKMapView, didSelectAnnotationView view: MKAnnotationView) {

        if let annotation = view.annotation as? TouringLocationAnnotation {
            let selectedPin = annotation.tourLocationPin as! Pin //for photos or removal
            
            if editModeOn == false {
                if annotation.tourLocationPin.isFetchingPhotos == true {
                    alertUserForError("We are trying to retrieve photos from Flickr for this location, please wait...")
                } else {
                    //jump to the photo collection view for the selectedPin
                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                        self.openPhotoViewForPin(selectedPin)
                    })
                    
                    // print("did select the annotation View, getting its coordinates, latitude: \(latitude), longitude: \(longitude)")
                }
            } else {
                //remove the pin
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    self.mapView.removeAnnotation(annotation)
                    self.sharedContext.deleteObject(selectedPin)
                    CoreDataStackManager.sharedInstance().saveContext()
                })
            }
        }
    }
    
    
    internal func openPhotoViewForPin(selectedPin: Pin) {
        
        let targetController = storyboard?.instantiateViewControllerWithIdentifier("PhotoCollectionBoard") as! PhotoCollectionViewController
        targetController.selectedPin = selectedPin
        self.navigationController?.pushViewController(targetController, animated: true)
    }
    

  
}

