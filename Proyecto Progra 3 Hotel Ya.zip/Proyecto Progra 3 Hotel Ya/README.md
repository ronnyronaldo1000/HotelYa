#Proyecto progra 3 : HotelYa con MapKit and Fotos de Flickr
- CoreData/iOS
- Requerimientos para la compilacion Swift 2.0/XCode 7.0 or newer
